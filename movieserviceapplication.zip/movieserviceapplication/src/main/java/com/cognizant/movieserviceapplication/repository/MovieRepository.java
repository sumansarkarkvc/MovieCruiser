package com.cognizant.movieserviceapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.movieserviceapplication.domain.Movie;

public interface MovieRepository extends JpaRepository <Movie, Integer> {

	// CRUD Repository for Movie class

}
