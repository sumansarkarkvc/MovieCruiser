package com.cognizant.movieserviceapplication.exception;

public class MovieNotFoundException extends Exception {
	
	
     // custom exception when a movie does not exist when searched by its Id
     // @param message

	
	String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public MovieNotFoundException(final String message) {
		super(message);
		this.message=message;
	}
	
	@Override
	public String toString() {
		return "MovieNotFoundException [message=" + message + " ]";
	}

}
