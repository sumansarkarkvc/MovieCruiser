package com.cognizant.movieserviceapplication.service;

import java.util.List;

import com.cognizant.movieserviceapplication.domain.Movie;
import com.cognizant.movieserviceapplication.exception.MovieAlreadyExistsException;
import com.cognizant.movieserviceapplication.exception.MovieNotFoundException;

public interface MovieService {
	
	
    // method declaration for saving a movie
    // @param movie
    // @return true/false
    // @throws MovieAlreadyExistsException
 
	
	boolean saveMovie(Movie movie) throws MovieAlreadyExistsException;
	
    
    // method declaration for updating movie comments
    // @param movie
    // @return movie
    // @throws MovieNotFoundException

	
	Movie updateMovie(Movie movie) throws MovieNotFoundException;
	
    
    // method declaration for deleting a movie
    // @param id
    // @return true/false
    // @throws MovieNotFoundException

	
	boolean deleteMovieById(int id) throws MovieNotFoundException;
	
    
    // method declaration for getting a movie using movie id
    // @param id
    // @return movie
    // @throws MovieNotFoundException

	
	Movie getMovieById(int id) throws MovieNotFoundException;
	
    
    // method declaration for getting list of all movies
    // @return ArrayList<Movie>
    
	
	List<Movie> getAllMovies();
}
