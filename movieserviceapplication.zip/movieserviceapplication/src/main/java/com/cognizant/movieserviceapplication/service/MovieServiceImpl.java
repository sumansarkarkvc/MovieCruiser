package com.cognizant.movieserviceapplication.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieserviceapplication.domain.Movie;
import com.cognizant.movieserviceapplication.exception.MovieAlreadyExistsException;
import com.cognizant.movieserviceapplication.exception.MovieNotFoundException;
import com.cognizant.movieserviceapplication.repository.MovieRepository;


// service class to implement all methods declared in MovieService interface


@Service
public class MovieServiceImpl implements MovieService {
	
	
    // reference to movieRepo object
     

	private final transient MovieRepository movieRepo;
	
	
    // initializing the movieRepo object
    // @param movieRepo

	
	@Autowired
	public MovieServiceImpl(final MovieRepository movieRepo) {
		super();
		this.movieRepo = movieRepo;
	}
	
	
    // save the movie

	
	@Override
	public boolean saveMovie(final Movie movie) throws MovieAlreadyExistsException {
	
	final Optional<Movie> object = movieRepo.findById(movie.getId());
	
	if(object.isPresent())
	{
		throw new MovieAlreadyExistsException("Movie not saved, Movie already exists");
	}
	movieRepo.save(movie);
	return true;
    }
	
    
    // update the movie

	
	@Override
	public Movie updateMovie(Movie movie) throws MovieNotFoundException {
		final Movie updateMovie=movieRepo.findById(movie.getId()).orElse(null);
		if (updateMovie == null) {
			throw new MovieNotFoundException("Movie not updated, Movie not found");
		}
		updateMovie.setComments(movie.getComments());
		movieRepo.save(updateMovie);
		return updateMovie;

	}
	
	
	// delete the movie
	
	
	@Override
	public boolean deleteMovieById(int id) throws MovieNotFoundException {
		final Movie movie=movieRepo.findById(id).orElse(null);
		if (movie == null) {
			throw new MovieNotFoundException("Could not delete. Movie not found");
		}
        movieRepo.delete(movie);
		return true;
	}

	
	// find movie using movie Id
	
	
	@Override
	public Movie getMovieById(int id) throws MovieNotFoundException {
		final Movie movie = movieRepo.findById(id).get();
		if (movie == null) {
			throw new MovieNotFoundException("Movie not found");
		}
		return movie;
	}

	
	// fetch all movies from database
	
	
	@Override
	public List<Movie> getAllMovies() {
		return movieRepo.findAll();
	}

}
