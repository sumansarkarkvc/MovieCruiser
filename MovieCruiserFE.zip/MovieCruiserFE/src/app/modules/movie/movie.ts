export interface Movie {
    title : String;
    poster_path : String;
    overview : String;
    release_date : String;
}