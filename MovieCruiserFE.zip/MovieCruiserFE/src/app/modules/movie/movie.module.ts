import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HelloWorldComponent } from './components/hello-world/hello-world.component';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { HttpClientModule } from '@angular/common/http';
import { MovieService } from './movie.service';
import { PopularComponent } from './components/popular/popular.component';

@NgModule({
  declarations: [HelloWorldComponent, ThumbnailComponent, PopularComponent],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  exports: [
    HelloWorldComponent,
    ThumbnailComponent,
    PopularComponent
  ],
  providers : [ MovieService
   ]
})
export class MovieModule { }
