import { Component } from '@angular/core';
import { HelloWorldComponent } from './modules/movie/components/hello-world/hello-world.component';
import { PopularComponent } from './modules/movie/components/popular/popular.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MovieServiceFrontend';
}
